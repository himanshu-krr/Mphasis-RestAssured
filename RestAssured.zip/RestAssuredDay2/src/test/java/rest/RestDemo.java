package rest;

import java.io.FileReader;
import java.io.IOException;
import java.util.Base64;
import java.util.Properties;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class RestDemo {

    public int post_demo() throws IOException {
        
        // Load request body properties
        String bodyPath = "./TestData/testbody.properties";
        FileReader bodyReader = new FileReader(bodyPath);
        Properties bodyProps = new Properties();
        bodyProps.load(bodyReader);
        
        // Load test data properties
        String dataPath = "./TestData/testdata.properties";
        FileReader dataReader = new FileReader(dataPath);
        Properties dataProps = new Properties();
        dataProps.load(dataReader);
        
        // Get values from properties file
        String baseURI = dataProps.getProperty("burig"); // https://reqres.in
        String endPoint = dataProps.getProperty("epg"); // /api/users/2
        String reqBody = bodyProps.getProperty("tbd1"); // JSON request body

        // Set REST Assured base URI
        RestAssured.baseURI = baseURI;

        // Send PUT request
        Response res = RestAssured.given()
                .relaxedHTTPSValidation()
                .header("x-api-key", "reqres-free-v1")
                .body(reqBody)
                .put(endPoint);
        
        return res.getStatusCode();
    }

    public int Github_Rest() {
        RestAssured.baseURI = "https://api.github.com";
        String endPoint = "/users/himanshu-krr";

        Response res = RestAssured.given()
                .relaxedHTTPSValidation()
                .contentType(ContentType.JSON)
                .header("BearerToken","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")
                .get(endPoint);

        return res.getStatusCode();
    }

    public int basic_Auth() {
        RestAssured.baseURI = "https://postman-echo.com";
        String endpoint = "/basic-auth";
        String username = "postman", password = "password";
        String basicAuth = Base64.getEncoder().encodeToString((username + ":" + password).getBytes());

        Response res = RestAssured.given()
                .relaxedHTTPSValidation()
                .header("Authorization", "Basic " + basicAuth)
                .get(endpoint);
        
        return res.getStatusCode();
    }

    public static void main(String[] args) throws IOException {
        RestDemo r = new RestDemo();
        System.out.println("Post Demo Status: " + r.post_demo());
        System.out.println("GitHub API Status: " + r.Github_Rest());
        System.out.println("Basic Auth Status: " + r.basic_Auth());
    }
}
