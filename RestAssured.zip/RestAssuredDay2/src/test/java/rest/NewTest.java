package rest;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import rest.RestDemo;

public class NewTest {
    RestDemo r;

    @BeforeClass
    public void setup() {
        r = new RestDemo();
    }

    @Test
    public void gitdemo() {
        int statusCode = r.Github_Rest();
        assertEquals(statusCode, 200, "GitHub API request failed!");
    }

    @Test
    public void basic() {
        int statusCode = r.basic_Auth();
        assertEquals(statusCode, 200, "Basic authentication request failed!");
    }
}
