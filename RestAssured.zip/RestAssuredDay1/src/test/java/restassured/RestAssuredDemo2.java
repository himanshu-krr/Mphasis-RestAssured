package restassured;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
 
public class RestAssuredDemo2 {
	public static void main(String[] args) {
		
		// post
//		RestAssured.baseURI = "https://reqres.in/";
//		String endPoint = "/api/users";
//		String requestbody = "{\"name\":\"morpheus\",\"job\":\"leader56\"}";
//		Response response = RestAssured.given().relaxedHTTPSValidation().contentType(ContentType.JSON).header("x-api-key","reqres-free-v1").body(requestbody).post(endPoint);
//		int val = response.getStatusCode();
//		System.out.println(val);
//		String responseVal = response.getStatusLine();
//		System.out.println(responseVal);
		
		//put 
		RestAssured.baseURI = "https://reqres.in/";
		String endPoint = "/api/users/2";
		String requestbody = "{\"name\":\"himanshu\",\"job\":\"leader56\"}";
		Response response = RestAssured.given().relaxedHTTPSValidation().contentType(ContentType.JSON).header("x-api-key","reqres-free-v1").body(requestbody).put(endPoint);
		int val = response.getStatusCode();
		System.out.println(val);
		String responseVal = response.getStatusLine();
		System.out.println(responseVal);
		
		String body = response.getBody().asString();
		System.out.println(body);
	}
}
 