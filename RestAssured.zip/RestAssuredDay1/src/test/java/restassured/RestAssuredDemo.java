package restassured;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class RestAssuredDemo {
	
	public int statusCode()
	{
		Response res = RestAssured.given().relaxedHTTPSValidation().contentType(ContentType.JSON).get("https://automationexercise.com/api/productsList");
		int statusCode = res.getStatusCode();
		System.out.println(statusCode);
		return statusCode;
		
	}
	
	public static String grabStatusLine()
	{
		Response res = RestAssured.given().relaxedHTTPSValidation().contentType(ContentType.JSON).get("https://automationexercise.com/api/productsList");
		System.out.println(res.getStatusLine());
		return res.getStatusLine();
	}
	
	public ResponseBody getBody()
	{
		Response res = RestAssured.given().relaxedHTTPSValidation().contentType(ContentType.JSON).get("https://automationexercise.com/api/productsList");
		System.out.println(res.getBody());
		return res.getBody();
	}
	
	public String contentType()
	{
		Response res = RestAssured.given().relaxedHTTPSValidation().contentType(ContentType.JSON).get("https://automationexercise.com/api/productsList");
		System.out.println(res.getContentType());
		return res.getContentType();
	}
	
	public String sessionId()
	{
		Response res = RestAssured.given().relaxedHTTPSValidation().contentType(ContentType.JSON).get("https://automationexercise.com/api/productsList");
		System.out.println(res.getSessionId());
		return res.getSessionId();
	}
	
	
	
	public static void main(String[] args)
	{
	
		RestAssuredDemo ra = new RestAssuredDemo();
		ra.statusCode();
		grabStatusLine();
		ra.getBody();
		ra.contentType();
		ra.sessionId();
	}

}
// RestAssuredDemo