package restassured;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
 
public class Github {
	public static void main(String[] args) {
		RestAssured.baseURI = "https://api.github.com/";
		String endPoint = "users/himanshu-krr";
//		String requestbody = "{\"name\":\"morpheus\",\"job\":\"leader56\"}";
		Response response = RestAssured.given().relaxedHTTPSValidation().contentType(ContentType.JSON).header("BearerToken","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\r\n").get(endPoint);
		int val = response.getStatusCode();
		System.out.println(val);
		String responseVal = response.getStatusLine();
		System.out.println(responseVal);
		 
	}
}
 