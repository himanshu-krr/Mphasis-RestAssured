package restassured;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import io.restassured.response.ResponseBody;

public class RestAssuredDemoTest {

	RestAssuredDemo rad = new RestAssuredDemo();
  @Test
  public void statusTest() {
    int sc = rad.statusCode();
    assertEquals(200, sc);
    String sl = rad.grabStatusLine();
    assertEquals("HTTP/1.1 200 OK",sl);
    ResponseBody gb = rad.getBody();
//    assertEquals("io.restassured.internal.RestAssuredResponseImpl@1ffcf674",gb);
    String ct = rad.contentType();
    assertEquals("text/html; charset=utf-8",ct);
    String si = rad.sessionId();
    assertEquals(null,si);
  }
  
}